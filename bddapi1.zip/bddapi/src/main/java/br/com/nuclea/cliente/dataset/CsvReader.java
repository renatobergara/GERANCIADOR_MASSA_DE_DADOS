package br.com.nuclea.cliente.dataset;

import java.io.FileReader;
import java.io.Reader;
import java.util.List;

import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;

import br.com.nuclea.cliente.dataset.model.ApiTestData;

/**
 * CsvReader é uma classe utilitária responsável por ler dados de um arquivo CSV
 * e mapear as informações para uma lista de objetos do tipo
 * {@link ApiTestDataImpl}.
 * 
 * A classe utiliza a biblioteca OpenCSV para o mapeamento de dados do CSV para
 * objetos Java.
 * 
 * @param <M>
 */
public class CsvReader<M extends ApiTestData> {

	/**
	 * Lê um arquivo CSV e converte-o em uma lista de objetos da classe
	 * especificada.
	 * <p>
	 * O método utiliza a biblioteca OpenCSV para mapear as linhas do CSV em
	 * instâncias da classe fornecida. Funciona tanto em sistemas operacionais Linux
	 * quanto Windows, pois o caminho do arquivo é tratado de forma cross-platform.
	 * </p>
	 *
	 * @param <M>      o tipo de objeto que será mapeado a partir do CSV
	 * @param filePath o caminho completo do arquivo CSV
	 * @param clazz    a classe que representa cada linha do CSV
	 * @return uma lista de objetos do tipo {@code M} representando cada linha do
	 *         arquivo CSV
	 * @throws Exception se ocorrer um erro durante a leitura do arquivo ou no
	 *                   mapeamento dos dados
	 */
	@SuppressWarnings("hiding")
	public <M> List<M> readCsv(String filePath, Class<M> clazz) throws Exception {
		// Usa Reader com FileReader para ler o arquivo no caminho especificado
		try (Reader reader = new FileReader(filePath)) {
			// Constrói um CsvToBean com a classe fornecida
			CsvToBean<M> csvToBean = new CsvToBeanBuilder<M>(reader).withType(clazz).withIgnoreLeadingWhiteSpace(true) // Ignora
					.build();

			// Retorna a lista de objetos mapeados do arquivo CSV
			return csvToBean.parse();
		}
	}

}
