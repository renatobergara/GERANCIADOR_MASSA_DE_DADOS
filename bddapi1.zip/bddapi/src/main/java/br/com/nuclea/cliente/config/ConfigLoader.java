package br.com.nuclea.cliente.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigLoader {

	public static Properties propriedades() {
		Properties prop = new Properties();
		InputStream input = ConfigLoader.class.getClassLoader().getResourceAsStream("config.properties");
		try {
			prop.load(input);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return prop;

	}

}