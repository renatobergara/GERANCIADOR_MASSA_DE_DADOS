package br.com.nuclea.cliente.reports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import lombok.Getter;

public class ExtentReportUtil {

	@Getter
	private ExtentReports extent;
	@Getter
	private ExtentTest scenarioTest;

	public void setupExtentReport(ExtentSparkReporter htmlReporter) {
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
	}

	// Método para criar uma Feature
	public ExtentTest createFeature(String featureName) throws ClassNotFoundException {
		return extent.createTest(new GherkinKeyword("Feature"), featureName);
	}

	// Método para criar um Cenário
	public ExtentTest createScenario(ExtentTest feature, String scenarioName) throws ClassNotFoundException {
		return feature.createNode(new GherkinKeyword("Scenario"), scenarioName);
	}

	// Método para criar um passo Given
	public void createGivenStep(ExtentTest scenario, String stepDescription, boolean isPass)
			throws ClassNotFoundException {
		if (isPass) {
			scenario.createNode(new GherkinKeyword("Given"), stepDescription).pass("pass");
		} else {
			scenario.createNode(new GherkinKeyword("Given"), stepDescription).fail("fail");
		}
	}

	// Método para criar um passo And
	public void createAndStep(ExtentTest scenario, String stepDescription, boolean isPass)
			throws ClassNotFoundException {
		if (isPass) {
			scenario.createNode(new GherkinKeyword("And"), stepDescription).pass("pass");
		} else {
			scenario.createNode(new GherkinKeyword("And"), stepDescription).fail("fail");
		}
	}

	// Método para criar um passo When
	public void createWhenStep(ExtentTest scenario, String stepDescription, boolean isPass)
			throws ClassNotFoundException {
		if (isPass) {
			scenario.createNode(new GherkinKeyword("When"), stepDescription).pass("pass");
		} else {
			scenario.createNode(new GherkinKeyword("When"), stepDescription).fail("fail");
		}
	}

	// Método para criar um passo Then
	public void createThenStep(ExtentTest scenario, String stepDescription, boolean isPass)
			throws ClassNotFoundException {
		if (isPass) {
			scenario.createNode(new GherkinKeyword("Then"), stepDescription).pass("pass");
		} else {
			scenario.createNode(new GherkinKeyword("Then"), stepDescription).fail("fail");
		}
	}

	public void logInfo(String message) {
		scenarioTest.info(message);
	}

	public void finishReport() {
		extent.flush();
	}

}