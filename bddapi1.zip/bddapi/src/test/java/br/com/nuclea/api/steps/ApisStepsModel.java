package br.com.nuclea.api.steps;

import br.com.nuclea.cliente.dataset.model.ApiTestData;

public class ApisStepsModel extends ApiTestData {

}
