package br.com.nuclea.api.steps;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.jupiter.api.Assertions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.aventstack.extentreports.reporter.configuration.ViewName;

import br.com.nuclea.cliente.dataset.CsvFinder;
import br.com.nuclea.cliente.dataset.CsvReader;
import br.com.nuclea.cliente.dataset.model.ApiTestData;
import br.com.nuclea.cliente.reports.ExtentReportUtil;
import io.cucumber.java.After;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ApiSteps<M extends ApiTestData> {

	private static final Logger LOGGER = Logger.getLogger(ApiSteps.class.getName());
	private List<M> testDataList;
	private final CsvReader<M> csvReader = new CsvReader<M>();
	// Configuração do ExtentReports
	public static ExtentTest test;

	public static String className;

	private ExtentReportUtil report;

	@Given("A API está pronta para receber requisições")
	public void setupApi() {
		LOGGER.log(Level.CONFIG, "Iniciando o relatório");
		if (className == null) {
			className = setupReportName();

			// Gerar o timestamp atual para incluir no nome do arquivo
			String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));

			// Definir o caminho do relatório na pasta da classe de teste com data e hora
			String reportPath = Paths.get(System.getProperty("user.dir"), className + "_" + timestamp + ".html")
					.toString();

			if (!new File(reportPath).exists()) {
				ExtentSparkReporter htmlReporter = new ExtentSparkReporter(reportPath).viewConfigurer().viewOrder()
						.as(new ViewName[] { ViewName.DASHBOARD, ViewName.TEST }).apply();
				htmlReporter.config().setTheme(Theme.DARK);
				htmlReporter.config().setDocumentTitle("Relatório de Testes API");
				htmlReporter.config().setReportName("Execução de Testes Automatizados");
				report = new ExtentReportUtil();
				report.setupExtentReport(htmlReporter);
				try {
					test = report.createFeature("Teste de APIs diversas");
					report.createScenario(test, "Validar múltiplas ações na API.");
					report.createGivenStep(test, "A API está pronta para receber requisições", true);
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
		}
		LOGGER.log(Level.CONFIG, "Iniciando a carga de dados para o teste.");
		carregaDadosParaTeste();

//		RestAssured.baseURI = "https://api.exemplo.com";
	}

	@When("Eu faço uma requisição POST na API {string}")
	public void eu_faco_uma_requisicao_post_na_api(String endpoint) {
		System.out.println("Enviando xpto");
		try {
			report.createWhenStep(test, "Eu faço uma requisição POST na API {string}", true);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@When("Eu envio o seguinte payload:")
	public void eu_envio_o_seguinte_payload(String docString) {
		// Aqui você pode processar o payload recebido, que é esperado como um
		// DocString.
		// Por exemplo, você pode armazenar o payload ou enviá-lo para um serviço.

		// O docString pode ser acessado como uma string.
		// O Cucumber interpreta o conteúdo até a próxima linha em um DocString.
		// Aqui está um exemplo de como você poderia armazenar o payload:
		System.out.println("Payload recebido: ");
		try {
			report.createWhenStep(test, "Eu envio o seguinte payload:", true);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		// Você pode lançar a exceção PendingException se ainda não tiver implementado a
		// lógica.
		// throw new io.cucumber.java.PendingException();
	}

	@Then("O status code da resposta deve ser {int}")
	public void validar_status_code(int statusCode) {
		try {
			report.createThenStep(test, "O status code da resposta deve ser {int}", true);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Assertions.assertEquals("", "");
	}

	@Then("A resposta deve conter o campo {string}")
	public void validar_campo_na_resposta(String campo) {
		try {
			report.createThenStep(test, "A resposta deve conter o campo {string}", true);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		Assertions.assertTrue(true);
	}

	@Then("O campo {string} deve ser {string}")
	public void validar_valor_do_campo(String campo, String valorEsperado) {
		try {
			report.createThenStep(test, "O campo {string} deve ser {string}", true);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		Assertions.assertEquals("", "");
	}

	protected void carregaDadosParaTeste() {
		// Ler os dados do CSV
		testDataList = readTestData();
	}

	/**
	 * Lê os dados do arquivo CSV e mapeia para uma lista de objetos
	 * {@link ApiTestData}.
	 *
	 * @param csvFilePath O caminho do arquivo CSV.
	 * @return Uma lista de dados de teste ou null em caso de falha.
	 */
	@SuppressWarnings("unchecked")
	private List<M> readTestData() {
		// Chama o método para procurar o arquivo
		try {
			return (List<M>) csvReader.readCsv(getCsvFilePath(), modelo().getClass());
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Erro ao ler o arquivo CSV: {0}", getCsvFilePath());
			LOGGER.log(Level.SEVERE, "Erro ao ler o arquivo CSV: {0}", e.getMessage());
			test.log(Status.FAIL, e.getMessage());
			return null;
		}
	}

	/**
	 * Gera o caminho do arquivo CSV com base no nome da classe de teste. O arquivo
	 * CSV terá o mesmo nome da classe e estará localizado no mesmo diretório da
	 * classe.
	 *
	 * @return O caminho completo do arquivo CSV.
	 */
	private String getCsvFilePath() {
		// Obter o nome da classe de teste
		String className = this.getClass().getSimpleName();

		// Criar o caminho para o arquivo CSV
		File csvFile = new File(className + ".csv");

		// Dividindo o caminho pelo caractere '/'
		String[] pathParts = csvFile.getAbsolutePath().split("\\\\");

		// Criando um novo array sem a última posição
		String[] trimmedPathParts = new String[pathParts.length - 1];
		System.arraycopy(pathParts, 0, trimmedPathParts, 0, pathParts.length - 1);

		// Exibindo o caminho resultante
		StringBuilder resultPath = new StringBuilder();
		for (String part : trimmedPathParts) {
			resultPath.append(part).append("\\");
		}

		// Removendo a última barra, se existir
		if (resultPath.length() > 0) {
			resultPath.setLength(resultPath.length() - 1); // Remove a última barra
		}

		try {
			System.out.println(CsvFinder.findCsvFiles(Paths.get(resultPath.toString()), csvFile.getName()));
			Optional<Path> pathCsv = CsvFinder.findCsvFiles(Paths.get(resultPath.toString()), csvFile.getName());
			return pathCsv.get().toString();

		} catch (IOException e) {
			System.err.println("Erro ao procurar arquivos: " + e.getMessage());
			test.log(Status.FAIL, e.getMessage());
		}
		return "";

	}

	@After
	public void tearDown() {
		report.finishReport();// Gera o relatório
	}

	// Método abstrato que representa o modelo dos dados que serão carregados no
	// teste.
	protected M modelo() {
		return (M) new ApisStepsModel();
	}

	@BeforeAll
	protected String setupReportName() {
		return this.getClass().getSimpleName();
	}

}