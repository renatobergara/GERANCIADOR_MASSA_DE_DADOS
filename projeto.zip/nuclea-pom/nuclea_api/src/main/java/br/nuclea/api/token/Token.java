package br.nuclea.api.token;

/**
 * A interface Token define um contrato para a obtenção de um token de
 * autenticação. Implementações dessa interface devem fornecer uma lógica para
 * enviar uma requisição de login e recuperar um token a partir de uma URL e
 * credenciais fornecidas.
 */
public interface Token {

	/**
	 * Obtém um token de autenticação a partir de uma URL, usando um nome de usuário
	 * e senha.
	 * 
	 * Esse método deve ser implementado para enviar uma requisição (geralmente
	 * POST) para o endpoint de login, fornecendo as credenciais do usuário, e
	 * recuperar o token de autenticação da resposta.
	 * 
	 * @param url      A URL do serviço de autenticação.
	 * @param username O nome de usuário utilizado para a autenticação.
	 * @param password A senha correspondente ao nome de usuário.
	 * @param path     O caminho adicional da URL, se necessário, para obter o
	 *                 token.
	 * @return O token de autenticação como uma {@link String}.
	 */
	public String getToken(String url, String username, String password, String path);

}