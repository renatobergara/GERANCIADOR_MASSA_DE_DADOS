package br.nuclea.api.baseteste;

import org.junit.jupiter.api.TestInfo;

/**
 * Interface BaseTesteBean define os métodos para testes de sucesso e testes
 * negativos.
 *
 * @param <M> o tipo de dado que será testado.
 */
public interface BaseTesteBean<M> {

	/**
	 * Executa um teste de sucesso com base nas informações do teste fornecidas.
	 *
	 * @param testInfo as informações do teste, fornecidas pela classe de teste.
	 */
	public void testSucesso(TestInfo testInfo);

	/**
	 * Executa um teste negativo com base nas informações do teste fornecidas.
	 *
	 * @param testInfo as informações do teste, fornecidas pela classe de teste.
	 */
	public void testNegativo(TestInfo testInfo);

}
