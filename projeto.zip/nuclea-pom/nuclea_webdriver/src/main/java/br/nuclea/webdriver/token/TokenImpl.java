package br.nuclea.webdriver.token;

import br.nuclea.api.token.Token;
import io.restassured.RestAssured;
import io.restassured.response.Response;

/**
 * A classe TokenImpl é uma implementação da interface {@link Token} que obtém
 * um token de autenticação via requisição HTTP POST. Esta classe utiliza a
 * biblioteca RestAssured para enviar a requisição e obter o token da resposta.
 */
public class TokenImpl implements Token {

	// O tipo de conteúdo padrão utilizado na requisição (JSON).
	private static final String CONTENT_TYPE = "application/json";

	/**
	 * Envia uma requisição HTTP POST para uma URL de autenticação, utilizando o
	 * nome de usuário e senha fornecidos, e retorna o token de autenticação a
	 * partir do caminho especificado na resposta.
	 *
	 * @param url      A URL do serviço de autenticação.
	 * @param username O nome de usuário utilizado para autenticação.
	 * @param password A senha correspondente ao nome de usuário.
	 * @param path     O caminho específico dentro da resposta JSON onde o token
	 *                 será extraído.
	 * @return Uma String contendo o token de autenticação extraído da resposta da
	 *         API.
	 */
	@Override
	public String getToken(String url, String username, String password, String path) {
		Response response = RestAssured.given().contentType(CONTENT_TYPE)
				.body("{\"username\": \"" + username + "\", \"password\": \"" + password + "\"}").post(url);

		return response.jsonPath().getString(path);
	}

}
