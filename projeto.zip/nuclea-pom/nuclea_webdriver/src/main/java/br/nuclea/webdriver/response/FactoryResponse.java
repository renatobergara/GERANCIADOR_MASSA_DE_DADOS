package br.nuclea.webdriver.response;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * FactoryResponse é uma classe utilitária que fornece métodos para construir e
 * enviar requisições HTTP usando a biblioteca RestAssured. A classe permite
 * adicionar headers, parâmetros, e corpo (body) nas requisições. Ela é
 * projetada para ser usada de forma estática, evitando a criação de instâncias.
 */
public class FactoryResponse {

	/**
	 * Construtor privado para evitar a criação de instâncias da classe utilitária.
	 */
	private FactoryResponse() {
	}

	/**
	 * Envia uma requisição GET para uma URL com token de autenticação, header,
	 * parâmetros e corpo.
	 *
	 * @param url    A URL para a qual a requisição será enviada.
	 * @param token  O token de autenticação no formato Bearer.
	 * @param header Header personalizado que será adicionado à requisição.
	 * @param param  Parâmetro de consulta a ser adicionado à URL.
	 * @param body   Corpo da requisição que será enviado.
	 * @return A resposta da requisição HTTP.
	 */
	public static Response getResponse(String url, String token, String header, String param, String body) {
		RequestSpecification request = criaRequestComHeaderEAuth(token, header);
		adicionaParam(request, param);
		adicionaBody(request, body);
		return request.get(url);
	}

	/**
	 * Envia uma requisição GET simples para uma URL sem headers, parâmetros ou
	 * corpo.
	 *
	 * @param url A URL para a qual a requisição será enviada.
	 * @return A resposta da requisição HTTP.
	 */
	public static Response getSimpleResponse(String url, String token) {
		return RestAssured.given().header("Authorization", "Bearer " + token).get(url);
	}

	/**
	 * Envia uma requisição GET simples para uma URL sem headers, parâmetros ou
	 * corpo.
	 *
	 * @param url A URL para a qual a requisição será enviada.
	 * @return A resposta da requisição HTTP.
	 */
	public static Response getSimpleResponse(String url) {
		return RestAssured.given().get(url);
	}

	/**
	 * Envia uma requisição GET para uma URL com token de autenticação, header e
	 * parâmetros, mas sem corpo.
	 *
	 * @param url    A URL para a qual a requisição será enviada.
	 * @param token  O token de autenticação no formato Bearer.
	 * @param header Header personalizado que será adicionado à requisição.
	 * @param param  Parâmetro de consulta a ser adicionado à URL.
	 * @return A resposta da requisição HTTP.
	 */
	public static Response getResponseWithoutBody(String url, String token, String header, String param) {
		RequestSpecification request = criaRequestComHeaderEAuth(token, header);
		adicionaParam(request, param);
		return request.get(url);
	}

	/**
	 * Envia uma requisição GET para uma URL com token de autenticação, header e
	 * corpo, mas sem parâmetros.
	 *
	 * @param url    A URL para a qual a requisição será enviada.
	 * @param token  O token de autenticação no formato Bearer.
	 * @param header Header personalizado que será adicionado à requisição.
	 * @param body   Corpo da requisição que será enviado.
	 * @return A resposta da requisição HTTP.
	 */
	public static Response getResponseWithoutParam(String url, String token, String header, String body) {
		RequestSpecification request = criaRequestComHeaderEAuth(token, header);
		adicionaBody(request, body);
		return request.get(url);
	}

	/**
	 * Envia uma requisição GET para uma URL com parâmetros e corpo, mas sem
	 * headers.
	 *
	 * @param url   A URL para a qual a requisição será enviada.
	 * @param param Parâmetro de consulta a ser adicionado à URL.
	 * @param body  Corpo da requisição que será enviado.
	 * @return A resposta da requisição HTTP.
	 */
	public static Response getResponseWithoutHeader(String url, String param, String body) {
		RequestSpecification request = RestAssured.given();
		adicionaParam(request, param);
		adicionaBody(request, body);
		return request.get(url);
	}

	/**
	 * Cria uma requisição com headers personalizados e autenticação com token.
	 *
	 * @param token  O token de autenticação no formato Bearer.
	 * @param header Header personalizado que será adicionado à requisição.
	 * @return Um objeto RequestSpecification com headers e autenticação
	 *         configurados.
	 */
	private static RequestSpecification criaRequestComHeaderEAuth(String token, String header) {
		return RestAssured.given().header("Authorization", "Bearer " + token).header("Custom-Header", header);
	}

	/**
	 * Adiciona parâmetros à requisição, caso estejam definidos.
	 *
	 * @param request O objeto RequestSpecification ao qual os parâmetros serão
	 *                adicionados.
	 * @param param   O parâmetro de consulta a ser adicionado.
	 */
	private static void adicionaParam(RequestSpecification request, String param) {
		if (param != null && !param.isEmpty()) {
			request.param("queryParam", param);
		}
	}

	/**
	 * Adiciona um corpo à requisição, caso esteja definido.
	 *
	 * @param request O objeto RequestSpecification ao qual o corpo será adicionado.
	 * @param body    O corpo da requisição que será enviado.
	 */
	private static void adicionaBody(RequestSpecification request, String body) {
		if (body != null && !body.isEmpty()) {
			request.body(body);
		}
	}

}
