package br.nuclea.cliente.testes;

import com.opencsv.bean.CsvBindByName;

import br.nuclea.cliente.dataset.model.ApiTestData;
import lombok.Getter;
import lombok.Setter;

public class TesteXPTOModel extends ApiTestData {

	@Getter
	@Setter
	@CsvBindByName(column = "message")
	private String message;

	@Getter
	@Setter
	@CsvBindByName(column = "teste1")
	private String teste1;

}
