package br.nuclea.cliente.testes;

import br.nuclea.cliente.dataset.model.ApiResponseModel;
import lombok.Getter;
import lombok.Setter;

public class JsonXPTOModel extends ApiResponseModel {

	@Getter
	@Setter
	private String teste1;

}
