package br.nuclea.cliente.testes;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;

import org.opentest4j.AssertionFailedError;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import br.nuclea.cliente.baseteste.BaseTestCase;
import br.nuclea.cliente.dataset.JsonReader;
import br.nuclea.cliente.report.TestReport;
import br.nuclea.webdriver.response.FactoryResponse;
import br.nuclea.webdriver.token.TokenImpl;
import io.restassured.response.Response;

public class TesteXPTO extends BaseTestCase<TesteXPTOModel> {

	@Override
	public String setupReportName() {
		return TesteXPTO.class.getSimpleName();
	}

	public TesteXPTOModel modelo() {
		return new TesteXPTOModel();
	}

	@Override
	protected Response executeApiRequest(TesteXPTOModel testData) {
		return FactoryResponse.getSimpleResponse(apiUrlToken(), token(testData));
	}

	@Override
	protected void validateResponse(Response response, TesteXPTOModel dados, ExtentReports extent, ExtentTest test) {
//		Response response = executeApiRequest(token, testData);

		JsonReader<JsonXPTOModel> jsonReader = new JsonReader<>(JsonXPTOModel.class);
		try {
			// Lendo de um arquivo
			JsonXPTOModel responseTesteFixo = jsonReader.readFromFile(
					"C:\\projetos\\Nuclea_API\\nuclea-pom\\nuclea_cliente\\src\\test\\java\\br\\nuclea\\cliente\\testes\\teste.json");
			System.out.println("Status: " + responseTesteFixo.getStatus());
			System.out.println("Mensagem: " + responseTesteFixo.getMessage());
			System.out.println("Teste1 : " + responseTesteFixo.getTeste1());

			assertEquals(responseTesteFixo.getStatus(), dados.getStatusTest());
			new TestReport().logPass(extent, test, "Passou", dados.getStatusTest(), responseTesteFixo.getStatus());

		} catch (IOException | AssertionFailedError e) {

			new TestReport().logFail(extent, test, e.getStackTrace().toString());
			new TestReport().log(extent, test, e);

		}
	}

	@Override
	protected String token(TesteXPTOModel dados) {
		return new TokenImpl().getToken("URL", "username", "password", "path");
	}

	@Override
	protected String apiUrlToken() {
		return "";
	}

}
