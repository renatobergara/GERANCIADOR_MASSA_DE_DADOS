package br.nuclea.cliente.report;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class TestReport {

	public void logPass(ExtentReports extent, ExtentTest test, String message, String esperado, String gerado) {
		test.log(Status.PASS, message);
	}

	public void logFail(ExtentReports extent, ExtentTest test, String message) {
		test.log(Status.FAIL, message);
	}

	public void log(ExtentReports extent, ExtentTest test, Throwable message) {
		test.log(Status.FAIL, message);
	}

	public void logSkip(ExtentReports extent, ExtentTest test, String message) {
		test.log(Status.SKIP, message);
	}

}
