package br.nuclea.cliente.baseteste;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.aventstack.extentreports.reporter.configuration.ViewName;

import br.nuclea.api.baseteste.BaseTesteBean;
import br.nuclea.cliente.dataset.CsvFinder;
import br.nuclea.cliente.dataset.CsvReader;
import br.nuclea.cliente.dataset.model.ApiTestData;
import io.restassured.response.Response;

/**
 * A classe BaseTestCase implementa testes de API automatizados usando dados de
 * um CSV e valida as respostas da API. Ela contém métodos para testar cenários
 * de sucesso e negativos, reutilizando lógica comum e simplificando a execução
 * dos testes.
 */
public abstract class BaseTestCase<M extends ApiTestData> implements BaseTesteBean<M> {

	private static final Logger LOGGER = Logger.getLogger(BaseTestCase.class.getName());

	private TestInfo testinfo;
	private List<M> testDataList;

	private final CsvReader<M> csvReader = new CsvReader<M>();

	// Configuração do ExtentReports
	private static ExtentReports extent;
	public static ExtentTest test;

	public static String className;

	@BeforeEach
	public void setupReport() {
		LOGGER.log(Level.CONFIG, "Iniciando o relatório");
		if (className == null) {
			className = setupReportName();

			// Gerar o timestamp atual para incluir no nome do arquivo
			String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));

			// Definir o caminho do relatório na pasta da classe de teste com data e hora
			String reportPath = Paths.get(System.getProperty("user.dir"), className + "_" + timestamp + ".html")
					.toString();

			if (!new File(reportPath).exists()) {
				ExtentSparkReporter htmlReporter = new ExtentSparkReporter(reportPath).viewConfigurer().viewOrder()
						.as(new ViewName[] { ViewName.DASHBOARD, ViewName.TEST }).apply();
				htmlReporter.config().setTheme(Theme.DARK);
				htmlReporter.config().setDocumentTitle("Relatório de Testes API");
				htmlReporter.config().setReportName("Execução de Testes Automatizados");
				extent = new ExtentReports();
				extent.attachReporter(htmlReporter);
			}
		}

	}

	/**
	 * Teste de sucesso que obtém um token, lê os dados de um CSV e valida a
	 * resposta da API.
	 */
	@Test
	@Override
	public void testSucesso(TestInfo testInfo) {
		this.testinfo = testInfo;
		executeTestCase("Teste de sucesso");
	}

	@Test
	@Override
	public void testNegativo(TestInfo testInfo) {
		this.testinfo = testInfo;
		executeTestCase("Teste de sucesso Negativo");
	}

	/**
	 * Executa um caso de teste baseado nos dados fornecidos no arquivo CSV e na
	 * validação da resposta da API.
	 *
	 * @param csvFilePath    O caminho do arquivo CSV com os dados de teste.
	 * @param expectedStatus O status esperado na resposta da API.
	 */
	private void executeTestCase(String tipoDeTeste) {
		carregaDadosParaTeste();
		test = extent.createTest(tipoDeTeste);

		// Obter o token
//		String token = token(modelo());

		// Executar a requisição para cada conjunto de dados do CSV e validar a resposta
//
		for (M testData : testDataList) {
			ExtentTest childTest = test.createNode(testData.getNomeDoCenario() + " " + testData.getTeste());

			childTest.log(Status.INFO, "Teste de sucesso com dados: " + testData.toString());
			validateResponse(null, testData, extent, childTest);

			extent.flush();
		}
	}

	protected void carregaDadosParaTeste() {
		// Ler os dados do CSV
		List<M> list = readTestData();

		// Filtrando usando Stream
		testDataList = list.stream()
				.filter(item -> item.getMetodoTest().contains(testinfo.getDisplayName().split("\\(")[0]))
				.collect(Collectors.toList());

		if (testDataList == null || testDataList.isEmpty()) {
			LOGGER.log(Level.SEVERE, "Nenhum dado encontrado no arquivo CSV: {0}", getCsvFilePath());
			test.log(Status.INFO, "Nenhum dado encontrado no arquivo CSV: {0}" + getCsvFilePath());
			return;
		}

	}

	@BeforeAll
	protected abstract String setupReportName();

	// Método abstrato que representa o modelo dos dados que serão carregados no
	// teste.
	protected abstract M modelo();

	/**
	 * Valida a resposta da API com base no status esperado e no modelo da resposta.
	 *
	 * @param response       A resposta da API.
	 * @param expectedStatus O status esperado a ser validado.
	 */
	protected abstract void validateResponse(Response response, M dados, ExtentReports extent, ExtentTest test);

	@AfterEach
	public void tearDownReport() {
		extent.flush();
	}

	/**
	 * Gera um token com base nos dados fornecidos.
	 *
	 * @param dados Os dados necessários para gerar o token.
	 * @return Uma string representando o token gerado.
	 */
	protected abstract String token(M dados);

	/**
	 * Retorna a URL da API para a requisição do token.
	 *
	 * @return A URL da API como uma string.
	 */
	protected abstract String apiUrlToken();

	/**
	 * Executa uma requisição para a API com os dados de teste fornecidos.
	 *
	 * @param testData Os dados que serão utilizados na requisição da API.
	 * @return A resposta da API encapsulada em um objeto Response.
	 */
	protected abstract Response executeApiRequest(M testData);

	/**
	 * Lê os dados do arquivo CSV e mapeia para uma lista de objetos
	 * {@link ApiTestData}.
	 *
	 * @param csvFilePath O caminho do arquivo CSV.
	 * @return Uma lista de dados de teste ou null em caso de falha.
	 */
	@SuppressWarnings("unchecked")
	private List<M> readTestData() {
		// Chama o método para procurar o arquivo
		try {
			return (List<M>) csvReader.readCsv(getCsvFilePath(), modelo().getClass());
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Erro ao ler o arquivo CSV: {0}", getCsvFilePath());
			LOGGER.log(Level.SEVERE, "Erro ao ler o arquivo CSV: {0}", e.getMessage());
			test.log(Status.FAIL, e.getMessage());
			return null;
		}
	}

	/**
	 * Gera o caminho do arquivo CSV com base no nome da classe de teste. O arquivo
	 * CSV terá o mesmo nome da classe e estará localizado no mesmo diretório da
	 * classe.
	 *
	 * @return O caminho completo do arquivo CSV.
	 */
	private String getCsvFilePath() {
		// Obter o nome da classe de teste
		String className = this.getClass().getSimpleName();

		// Criar o caminho para o arquivo CSV
		File csvFile = new File(className + ".csv");

		// Dividindo o caminho pelo caractere '/'
		String[] pathParts = csvFile.getAbsolutePath().split("\\\\");

		// Criando um novo array sem a última posição
		String[] trimmedPathParts = new String[pathParts.length - 1];
		System.arraycopy(pathParts, 0, trimmedPathParts, 0, pathParts.length - 1);

		// Exibindo o caminho resultante
		StringBuilder resultPath = new StringBuilder();
		for (String part : trimmedPathParts) {
			resultPath.append(part).append("\\");
		}

		// Removendo a última barra, se existir
		if (resultPath.length() > 0) {
			resultPath.setLength(resultPath.length() - 1); // Remove a última barra
		}

		try {
			Optional<Path> pathCsv = CsvFinder.findCsvFiles(Paths.get(resultPath.toString()), csvFile.getName());
			return pathCsv.get().toString();

		} catch (IOException e) {
			System.err.println("Erro ao procurar arquivos: " + e.getMessage());
			test.log(Status.FAIL, e.getMessage());
		}
		return "";

	}

}
