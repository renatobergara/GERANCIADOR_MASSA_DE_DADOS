package br.nuclea.cliente.dataset;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * A classe CsvFinder é responsável por localizar arquivos CSV em um diretório
 * especificado. Ela procura por um arquivo CSV que corresponda ao nome
 * fornecido.
 */
public class CsvFinder {

	/**
	 * Procura por um arquivo CSV em um diretório especificado.
	 * <p>
	 * A busca é recursiva, varrendo subdiretórios também. O método retorna um
	 * Optional contendo o caminho do arquivo, caso encontrado. Se o arquivo não for
	 * encontrado, retorna um Optional vazio.
	 * </p>
	 *
	 * @param directory o diretório onde a busca será realizada
	 * @param fileName  o nome do arquivo CSV que está sendo procurado
	 * @return um {@code Optional<Path>} contendo o caminho do arquivo encontrado,
	 *         ou vazio se não encontrado
	 * @throws IOException se ocorrer um erro de entrada/saída durante a busca
	 */
	public static Optional<Path> findCsvFiles(Path directory, String fileName) throws IOException {
		try (Stream<Path> paths = Files.walk(directory)) {
			return paths.filter(Files::isRegularFile) // Filtra apenas arquivos regulares
					.filter(path -> path.getFileName().toString().equals(fileName)) // Verifica se o nome do arquivo
																					// corresponde ao procurado
					.findFirst() // Retorna o primeiro arquivo encontrado
					.map(path -> {
						// No Linux, é importante garantir que os caminhos absolutos sejam corretamente
						// formatados
						System.out.println("Arquivo CSV encontrado: " + path.toAbsolutePath());
						return path.toAbsolutePath();
					});
		}
	}
}