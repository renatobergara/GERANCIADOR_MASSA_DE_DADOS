package br.nuclea.cliente.dataset;

import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonReader<T> {
	private final Class<T> modelClass;

	public JsonReader(Class<T> modelClass) {
		this.modelClass = modelClass;
	}

	public T readFromFile(String filePath) throws IOException {
		return new ObjectMapper().readValue(new File(filePath), modelClass);
	}

	public T readFromString(String jsonString) throws IOException {
		return new ObjectMapper().readValue(jsonString, modelClass);
	}

	// Caso apareça uma string em formato Json pode-se utilizar este método abaixo
	// comentado.
	// Lendo de uma string JSON
	// String jsonString = "{\"status\":\"success\",\"message\":\"Operação realizada
	// com sucesso.\"}";
	// ApiResponseModel responseFromString = jsonReader.readFromString(jsonString);
	// System.out.println("Status: " + responseFromString.getStatus());
	// System.out.println("Mensagem: " + responseFromString.getMessage());

}