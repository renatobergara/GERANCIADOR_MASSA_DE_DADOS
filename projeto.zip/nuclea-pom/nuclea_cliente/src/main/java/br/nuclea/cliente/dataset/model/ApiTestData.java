package br.nuclea.cliente.dataset.model;

import com.opencsv.bean.CsvBindByName;

import groovy.transform.EqualsAndHashCode;
import lombok.Data;

/**
 * Classe ApiTestData representa os dados de teste de uma API, mapeados a partir
 * de um arquivo CSV. Cada instância dessa classe armazena informações sobre um
 * cenário de teste, como o nome do cenário, o teste a ser executado, método,
 * parâmetros e outras informações relevantes para o teste da API.
 * <p>
 * A anotação {@code @Data} da biblioteca Lombok é utilizada para gerar
 * automaticamente os métodos getters, setters, equals, hashCode, e toString.
 * </p>
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ApiTestData {

	/**
	 * Nome do cenário de teste. Mapeado a partir da coluna "nomeDoCenario" do
	 * arquivo CSV.
	 */
	@CsvBindByName(column = "nomeDoCenario")
	private String nomeDoCenario;

	/**
	 * O nome do teste a ser executado. Mapeado a partir da coluna "test" do arquivo
	 * CSV.
	 */
	@CsvBindByName(column = "test")
	private String teste;

	/**
	 * O nome do método de teste que será chamado. Mapeado a partir da coluna
	 * "metodoTest" do arquivo CSV.
	 */
	@CsvBindByName(column = "metodoTest")
	private String metodoTest;

	/**
	 * O identificador único para o teste. Mapeado a partir da coluna "id" do
	 * arquivo CSV.
	 */
	@CsvBindByName(column = "id")
	private String id;

	/**
	 * Os dados do cabeçalho (header) da requisição. Mapeado a partir da coluna
	 * "header" do arquivo CSV.
	 */
	@CsvBindByName(column = "header")
	private String header;

	/**
	 * Os parâmetros da requisição. Mapeado a partir da coluna "param" do arquivo
	 * CSV.
	 */
	@CsvBindByName(column = "param")
	private String param;

	/**
	 * O corpo da requisição. Mapeado a partir da coluna "body" do arquivo CSV.
	 */
	@CsvBindByName(column = "body")
	private String body;

	/**
	 * O status esperado para o teste. Mapeado a partir da coluna "statusTest" do
	 * arquivo CSV.
	 */
	@CsvBindByName(column = "statusTest")
	private String statusTest;
}