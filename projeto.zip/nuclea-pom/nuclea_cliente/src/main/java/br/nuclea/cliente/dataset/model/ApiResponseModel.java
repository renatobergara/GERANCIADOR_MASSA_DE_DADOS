package br.nuclea.cliente.dataset.model;

import groovy.transform.EqualsAndHashCode;
import lombok.Data;

/**
 * Classe ApiResponseModel representa o modelo de resposta de uma API, contendo
 * o status da requisição e uma mensagem associada.
 * <p>
 * A anotação {@code @Data} da biblioteca Lombok é utilizada para gerar
 * automaticamente os métodos getters, setters, equals, hashCode, e toString.
 * </p>
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ApiResponseModel {

	private String status;
	private String message;

}
